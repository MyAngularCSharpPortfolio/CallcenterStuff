# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Ccr2::Application.config.secret_token = '10667768d302a110b8d1a8e26f0ef3b3848f430cdcda0f9f7bc6151ca26f164a9cdb5062884002dbc0e3a1b9af09128f20174433975042174eff7a432f168154'
