require 'spec_helper'

describe Call do
  pending "add some examples to (or delete) #{__FILE__}"
end
